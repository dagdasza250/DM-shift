/** @type {const} */
const themeColors = {
  primary: { light: '#00A8A8', dark: '#00A8A8' },
  background: { light: '#F8F9FA', dark: '#1A1A1A' },
  surface: { light: '#FFFFFF', dark: '#2D2D2D' },
  foreground: { light: '#2C3E50', dark: '#ECF0F1' },
  muted: { light: '#7F8C8D', dark: '#9BA1A6' },
  border: { light: '#BDC3C7', dark: '#404040' },
  success: { light: '#2ECC71', dark: '#27AE60' },
  warning: { light: '#F39C12', dark: '#E67E22' },
  error: { light: '#E74C3C', dark: '#C0392B' },
  accent: { light: '#FF6B35', dark: '#FF6B35' },
};

module.exports = { themeColors };
