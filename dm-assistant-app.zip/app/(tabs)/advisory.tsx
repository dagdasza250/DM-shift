import { ScrollView, Text, View, TouchableOpacity, Alert } from "react-native";
import { useState } from "react";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface ProductCategory {
  id: string;
  name: string;
  emoji: string;
  description: string;
  questions: string[];
  tips: string[];
}

const PRODUCT_CATEGORIES: ProductCategory[] = [
  {
    id: "skincare",
    name: "Pielęgnacja twarzy",
    emoji: "✨",
    description: "Kremy, serum, maski do twarzy",
    questions: [
      "Jaki typ skóry masz? (sucha, tłusta, mieszana, wrażliwa)",
      "Jakie są Twoje główne problemy? (zmarszczki, trądzik, przebarwienia)",
      "Czy masz alergię na jakieś składniki?",
      "Jak często chcesz się pielęgnować?",
    ],
    tips: [
      "Zawsze pytaj o typ skóry przed rekomendacją",
      "Sugeruj produkty do czyszczenia i nawilżania",
      "Wspomni o ochronie SPF w dzień",
      "Zaproponuj próbkę przed zakupem",
    ],
  },
  {
    id: "makeup",
    name: "Makijaż",
    emoji: "💄",
    description: "Podkład, róż, cień, pomadka",
    questions: [
      "Jaki typ podkładu preferujesz? (matowy, rozświetlający, naturalny)",
      "Jakie kolory Ci się podobają?",
      "Jak długo chcesz, aby makijaż się utrzymywał?",
      "Czy masz wrażliwą skórę?",
    ],
    tips: [
      "Zaproponuj próbę koloru na skórze",
      "Wyjaśnij różnicę między matowym a rozświetlającym",
      "Wspomni o trwałości produktu",
      "Zasugeruj pędzle lub gąbkę do aplikacji",
    ],
  },
  {
    id: "hair",
    name: "Włosy",
    emoji: "💇",
    description: "Szampony, odżywki, maski do włosów",
    questions: [
      "Jaki typ włosów masz? (proste, kręcone, faliste)",
      "Jakie są Twoje główne problemy? (łupież, wypadanie, suchość)",
      "Jak często myjesz włosy?",
      "Czy farbowałaś włosy?",
    ],
    tips: [
      "Pytaj o częstotliwość mycia",
      "Zaproponuj zestaw szamponu i odżywki",
      "Wyjaśnij działanie maski do włosów",
      "Wspomni o ochronie termicznej",
    ],
  },
  {
    id: "hygiene",
    name: "Higiena",
    emoji: "🧼",
    description: "Mydła, żele, dezodoranty",
    questions: [
      "Jaki typ skóry masz?",
      "Czy masz wrażliwą skórę?",
      "Czy preferujesz produkty naturalne?",
      "Jakie zapachy Ci się podobają?",
    ],
    tips: [
      "Zaproponuj produkty dermatologicznie testowane",
      "Wyjaśnij różnicę między mydłem a żelem",
      "Wspomni o ochronie przed bakteriami",
      "Zasugeruj dezodorant do danego typu skóry",
    ],
  },
  {
    id: "health",
    name: "Zdrowie",
    emoji: "💊",
    description: "Witaminy, suplementy, leki",
    questions: [
      "Jakie masz problemy zdrowotne?",
      "Czy bierzesz już jakieś suplementy?",
      "Czy masz alergię na coś?",
      "Czy jesteś w ciąży lub karmiąc?",
    ],
    tips: [
      "Zawsze pytaj o obecne leki",
      "Zaproponuj konsultację z farmaceutą",
      "Wyjaśnij działanie suplementu",
      "Wspomni o dawkowaniu",
    ],
  },
  {
    id: "home",
    name: "Produkty domowe",
    emoji: "🏠",
    description: "Środki czyszczące, perfumy do domu",
    questions: [
      "Jakie zapachy Ci się podobają?",
      "Czy masz alergię na zapachy?",
      "Jakie powierzchnie chcesz czyszczać?",
      "Czy preferujesz produkty ekologiczne?",
    ],
    tips: [
      "Zaproponuj zapachy sezonowe",
      "Wyjaśnij różnicę między produktami",
      "Wspomni o bezpieczeństwie dla dzieci",
      "Zasugeruj zestaw promocyjny",
    ],
  },
];

export default function AdvisoryScreen() {
  const colors = useColors();
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);

  const handleCategorySelect = (category: ProductCategory) => {
    setSelectedCategory(category);
    setCurrentQuestionIndex(0);
  };

  const handleNextQuestion = () => {
    if (selectedCategory && currentQuestionIndex < selectedCategory.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleFinishConversation = () => {
    Alert.alert(
      "Rozmowa zakończona",
      "Czy klient kupił produkt?",
      [
        { text: "Nie", onPress: () => setSelectedCategory(null) },
        { text: "Tak", onPress: () => {
          Alert.alert("Świetnie!", "Dziękujemy za sprzedaż!");
          setSelectedCategory(null);
        } },
      ]
    );
  };

  if (!selectedCategory) {
    return (
      <ScreenContainer className="p-4">
        <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
          <View className="flex-1 gap-4">
            {/* Header */}
            <View className="gap-2">
              <Text className="text-2xl font-bold text-foreground">Doradztwo klientowi</Text>
              <Text className="text-sm text-muted">Strukturyzowana rozmowa sprzedażowa</Text>
            </View>

            {/* Instructions */}
            <View 
              className="rounded-2xl p-4 gap-2"
              style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
            >
              <Text className="text-sm font-semibold text-foreground">Jak to działa?</Text>
              <Text className="text-xs text-muted leading-relaxed">
                1. Wybierz kategorię produktu{"\n"}
                2. Postępuj zgodnie z pytaniami{"\n"}
                3. Słuchaj uważnie potrzeb klienta{"\n"}
                4. Zaproponuj odpowiedni produkt{"\n"}
                5. Zasugeruj alternatywy
              </Text>
            </View>

            {/* Categories */}
            <View className="gap-2">
              <Text className="text-sm font-semibold text-foreground">Wybierz kategorię</Text>
              {PRODUCT_CATEGORIES.map((category) => (
                <TouchableOpacity
                  key={category.id}
                  onPress={() => handleCategorySelect(category)}
                  className="flex-row items-center gap-3 p-4 rounded-xl"
                  style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
                >
                  <Text className="text-2xl">{category.emoji}</Text>
                  <View className="flex-1">
                    <Text className="text-sm font-semibold text-foreground">{category.name}</Text>
                    <Text className="text-xs text-muted">{category.description}</Text>
                  </View>
                  <Text className="text-lg text-primary">›</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </ScrollView>
      </ScreenContainer>
    );
  }

  const currentQuestion = selectedCategory.questions[currentQuestionIndex];
  const isFirstQuestion = currentQuestionIndex === 0;
  const isLastQuestion = currentQuestionIndex === selectedCategory.questions.length - 1;

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-4">
          {/* Back Button */}
          <TouchableOpacity onPress={() => setSelectedCategory(null)}>
            <Text className="text-sm font-semibold text-primary">← Wróć</Text>
          </TouchableOpacity>

          {/* Category Header */}
          <View className="gap-2">
            <Text className="text-3xl">{selectedCategory.emoji}</Text>
            <Text className="text-2xl font-bold text-foreground">{selectedCategory.name}</Text>
            <Text className="text-sm text-muted">
              Pytanie {currentQuestionIndex + 1} z {selectedCategory.questions.length}
            </Text>
          </View>

          {/* Progress Bar */}
          <View 
            className="h-2 rounded-full overflow-hidden"
            style={{ backgroundColor: colors.border }}
          >
            <View 
              className="h-full rounded-full"
              style={{
                backgroundColor: colors.primary,
                width: `${((currentQuestionIndex + 1) / selectedCategory.questions.length) * 100}%`,
              }}
            />
          </View>

          {/* Current Question */}
          <View 
            className="rounded-2xl p-6 gap-4"
            style={{ backgroundColor: colors.surface, borderColor: colors.primary, borderWidth: 2 }}
          >
            <Text className="text-lg font-semibold text-foreground">{currentQuestion}</Text>
            <Text className="text-xs text-muted italic">
              Słuchaj uważnie odpowiedzi klienta i zapamiętaj szczegóły.
            </Text>
          </View>

          {/* Tips */}
          <View 
            className="rounded-2xl p-4 gap-2"
            style={{ backgroundColor: colors.success + "15" }}
          >
            <Text className="text-sm font-semibold text-foreground">💡 Porady</Text>
            {selectedCategory.tips.map((tip, idx) => (
              <Text key={idx} className="text-xs text-foreground">
                • {tip}
              </Text>
            ))}
          </View>

          {/* Navigation */}
          <View className="gap-2">
            <View className="flex-row gap-2">
              <TouchableOpacity
                onPress={handlePreviousQuestion}
                disabled={isFirstQuestion}
                className="flex-1 rounded-lg p-3 items-center"
                style={{
                  backgroundColor: isFirstQuestion ? colors.border : colors.muted,
                  opacity: isFirstQuestion ? 0.5 : 1,
                }}
              >
                <Text className="text-sm font-semibold text-white">← Wstecz</Text>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleNextQuestion}
                disabled={isLastQuestion}
                className="flex-1 rounded-lg p-3 items-center"
                style={{
                  backgroundColor: isLastQuestion ? colors.border : colors.primary,
                  opacity: isLastQuestion ? 0.5 : 1,
                }}
              >
                <Text className="text-sm font-semibold text-white">Dalej →</Text>
              </TouchableOpacity>
            </View>

            {isLastQuestion && (
              <TouchableOpacity
                onPress={handleFinishConversation}
                className="rounded-lg p-3 items-center"
                style={{ backgroundColor: colors.success }}
              >
                <Text className="text-sm font-semibold text-white">Zakończ rozmowę</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Missing Info Checklist */}
          <View 
            className="rounded-2xl p-4 gap-2"
            style={{ backgroundColor: colors.warning + "15" }}
          >
            <Text className="text-sm font-semibold text-foreground">⚠️ Przed rekomendacją</Text>
            <Text className="text-xs text-foreground">
              • Czy masz wszystkie informacje o potrzebach?{"\n"}
              • Czy pytałeś o alergię?{"\n"}
              • Czy znasz budżet klienta?{"\n"}
              • Czy pytałeś o preferencje?
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
