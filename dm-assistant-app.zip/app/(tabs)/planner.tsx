import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert } from "react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface Task {
  id: string;
  title: string;
  completed: boolean;
  priority: "high" | "medium" | "low";
  risk?: boolean;
}

interface PlannerData {
  tasks: Task[];
  risks: string[];
}

export default function PlannerScreen() {
  const colors = useColors();
  const [plannerData, setPlannerData] = useState<PlannerData>({
    tasks: [],
    risks: [],
  });
  const [newTaskTitle, setNewTaskTitle] = useState("");
  const [showAddTask, setShowAddTask] = useState(false);

  useEffect(() => {
    loadPlannerData();
  }, []);

  const loadPlannerData = async () => {
    try {
      const stored = await AsyncStorage.getItem("plannerData");
      if (stored) {
        setPlannerData(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading planner data:", error);
    }
  };

  const savePlannerData = async (data: PlannerData) => {
    try {
      await AsyncStorage.setItem("plannerData", JSON.stringify(data));
      setPlannerData(data);
    } catch (error) {
      console.error("Error saving planner data:", error);
    }
  };

  const addTask = () => {
    if (!newTaskTitle.trim()) {
      Alert.alert("Błąd", "Wpisz tytuł zadania");
      return;
    }

    const newTask: Task = {
      id: Date.now().toString(),
      title: newTaskTitle,
      completed: false,
      priority: "medium",
    };

    const updated = {
      ...plannerData,
      tasks: [...plannerData.tasks, newTask],
    };
    savePlannerData(updated);
    setNewTaskTitle("");
    setShowAddTask(false);
  };

  const toggleTask = (id: string) => {
    const updated = {
      ...plannerData,
      tasks: plannerData.tasks.map((t) =>
        t.id === id ? { ...t, completed: !t.completed } : t
      ),
    };
    savePlannerData(updated);
  };

  const deleteTask = (id: string) => {
    const updated = {
      ...plannerData,
      tasks: plannerData.tasks.filter((t) => t.id !== id),
    };
    savePlannerData(updated);
  };

  const completedCount = plannerData.tasks.filter((t) => t.completed).length;
  const completionPercent =
    plannerData.tasks.length > 0
      ? Math.round((completedCount / plannerData.tasks.length) * 100)
      : 0;

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return colors.error;
      case "medium":
        return colors.warning;
      case "low":
        return colors.success;
      default:
        return colors.muted;
    }
  };

  const getPriorityLabel = (priority: string) => {
    switch (priority) {
      case "high":
        return "Wysoki";
      case "medium":
        return "Średni";
      case "low":
        return "Niski";
      default:
        return priority;
    }
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">Plan zmiany</Text>
            <Text className="text-sm text-muted">Organizuj zadania i priorytety</Text>
          </View>

          {/* Progress */}
          <View 
            className="rounded-2xl p-4 gap-3"
            style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
          >
            <View className="flex-row items-center justify-between">
              <Text className="text-sm font-semibold text-foreground">Postęp</Text>
              <Text className="text-sm font-bold text-primary">{completionPercent}%</Text>
            </View>
            <View 
              className="h-2 rounded-full overflow-hidden"
              style={{ backgroundColor: colors.border }}
            >
              <View 
                className="h-full rounded-full"
                style={{
                  backgroundColor: colors.primary,
                  width: `${completionPercent}%`,
                }}
              />
            </View>
            <Text className="text-xs text-muted">
              {completedCount} z {plannerData.tasks.length} zadań
            </Text>
          </View>

          {/* Morning Checklist */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Poranny skan</Text>
            <View 
              className="rounded-xl p-3 gap-2"
              style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
            >
              <Text className="text-xs text-muted">✓ Sprawdzić poziom zapasów</Text>
              <Text className="text-xs text-muted">✓ Sprawdzić nowe produkty</Text>
              <Text className="text-xs text-muted">✓ Sprawdzić promocje dnia</Text>
              <Text className="text-xs text-muted">✓ Sprawdzić daty ważności</Text>
            </View>
          </View>

          {/* Tasks List */}
          <View className="gap-2">
            <View className="flex-row items-center justify-between">
              <Text className="text-sm font-semibold text-foreground">Zadania ({plannerData.tasks.length})</Text>
              <TouchableOpacity onPress={() => setShowAddTask(!showAddTask)}>
                <Text className="text-sm font-semibold text-primary">+ Dodaj</Text>
              </TouchableOpacity>
            </View>

            {showAddTask && (
              <View 
                className="rounded-xl p-3 gap-2"
                style={{ backgroundColor: colors.surface, borderColor: colors.primary, borderWidth: 1 }}
              >
                <TextInput
                  placeholder="Tytuł zadania"
                  placeholderTextColor={colors.muted}
                  value={newTaskTitle}
                  onChangeText={setNewTaskTitle}
                  className="p-2 rounded-lg border border-border text-foreground"
                  style={{ borderColor: colors.border, color: colors.foreground }}
                />
                <View className="flex-row gap-2">
                  <TouchableOpacity
                    onPress={addTask}
                    className="flex-1 rounded-lg p-2 items-center"
                    style={{ backgroundColor: colors.primary }}
                  >
                    <Text className="text-xs font-semibold text-white">Dodaj</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => setShowAddTask(false)}
                    className="flex-1 rounded-lg p-2 items-center"
                    style={{ backgroundColor: colors.border }}
                  >
                    <Text className="text-xs font-semibold text-foreground">Anuluj</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}

            {plannerData.tasks.length === 0 ? (
              <View 
                className="rounded-xl p-4 items-center"
                style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
              >
                <Text className="text-sm text-muted">Brak zadań. Dodaj pierwsze zadanie!</Text>
              </View>
            ) : (
              plannerData.tasks.map((task) => (
                <View
                  key={task.id}
                  className="flex-row items-center gap-3 p-3 rounded-lg"
                  style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
                >
                  <TouchableOpacity
                    onPress={() => toggleTask(task.id)}
                    className="w-6 h-6 rounded-full items-center justify-center"
                    style={{
                      backgroundColor: task.completed ? colors.success : colors.border,
                    }}
                  >
                    {task.completed && <Text className="text-xs text-white font-bold">✓</Text>}
                  </TouchableOpacity>
                  <View className="flex-1 gap-1">
                    <Text
                      className="text-sm font-medium text-foreground"
                      style={{
                        textDecorationLine: task.completed ? "line-through" : "none",
                        opacity: task.completed ? 0.6 : 1,
                      }}
                    >
                      {task.title}
                    </Text>
                    <Text className="text-xs text-muted">
                      Priorytet: {getPriorityLabel(task.priority)}
                    </Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => deleteTask(task.id)}
                    className="p-2"
                  >
                    <Text className="text-lg text-error">✕</Text>
                  </TouchableOpacity>
                </View>
              ))
            )}
          </View>

          {/* End of Shift Summary */}
          <View 
            className="rounded-2xl p-4 gap-2"
            style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
          >
            <Text className="text-sm font-semibold text-foreground">Podsumowanie zmiany</Text>
            <Text className="text-xs text-muted">
              Na koniec zmiany przejdź tutaj, aby udokumentować obserwacje i nieukończone zadania.
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
