import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert } from "react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface ShelfProblem {
  id: string;
  title: string;
  department: string;
  problem: string;
  solution: string;
  status: "open" | "resolved";
}

const DEPARTMENTS = [
  "Pielęgnacja twarzy",
  "Pielęgnacja ciała",
  "Włosy",
  "Makijaż",
  "Perfumy",
  "Higiena",
  "Produkty dziecięce",
  "Produkty domowe",
  "Zdrowie",
];

const PROBLEM_TYPES = [
  { id: "no-space", label: "Brak miejsca na półce", emoji: "📦" },
  { id: "new-product", label: "Nowy produkt bez miejsca", emoji: "🆕" },
  { id: "messy", label: "Chaos wizualny", emoji: "🌪️" },
  { id: "readability", label: "Niska czytelność", emoji: "👁️" },
  { id: "organization", label: "Zła organizacja", emoji: "🔀" },
];

export default function ShelfScreen() {
  const colors = useColors();
  const [problems, setProblems] = useState<ShelfProblem[]>([]);
  const [selectedDept, setSelectedDept] = useState("Pielęgnacja twarzy");
  const [selectedProblem, setSelectedProblem] = useState<string | null>(null);
  const [showAddProblem, setShowAddProblem] = useState(false);
  const [newProblemTitle, setNewProblemTitle] = useState("");

  useEffect(() => {
    loadProblems();
  }, []);

  const loadProblems = async () => {
    try {
      const stored = await AsyncStorage.getItem("shelfProblems");
      if (stored) {
        setProblems(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading shelf problems:", error);
    }
  };

  const saveProblems = async (data: ShelfProblem[]) => {
    try {
      await AsyncStorage.setItem("shelfProblems", JSON.stringify(data));
      setProblems(data);
    } catch (error) {
      console.error("Error saving shelf problems:", error);
    }
  };

  const addProblem = (problemType: string) => {
    if (!newProblemTitle.trim()) {
      Alert.alert("Błąd", "Wpisz opis problemu");
      return;
    }

    const problemLabel = PROBLEM_TYPES.find((p) => p.id === problemType)?.label || problemType;
    const newProblem: ShelfProblem = {
      id: Date.now().toString(),
      title: newProblemTitle,
      department: selectedDept,
      problem: problemLabel,
      solution: "",
      status: "open",
    };

    saveProblems([...problems, newProblem]);
    setNewProblemTitle("");
    setShowAddProblem(false);
    setSelectedProblem(null);
  };

  const resolveProblem = (id: string) => {
    const updated = problems.map((p) =>
      p.id === id ? { ...p, status: "resolved" as const } : p
    );
    saveProblems(updated);
  };

  const deleteProblem = (id: string) => {
    saveProblems(problems.filter((p) => p.id !== id));
  };

  const openProblems = problems.filter((p) => p.status === "open");
  const deptProblems = openProblems.filter((p) => p.department === selectedDept);

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">Półka i produkty</Text>
            <Text className="text-sm text-muted">Organizacja i rozmieszczenie</Text>
          </View>

          {/* Department Selector */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Dział</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} className="gap-2">
              {DEPARTMENTS.map((dept) => (
                <TouchableOpacity
                  key={dept}
                  onPress={() => setSelectedDept(dept)}
                  className="px-4 py-2 rounded-full"
                  style={{
                    backgroundColor: selectedDept === dept ? colors.primary : colors.surface,
                    borderColor: colors.border,
                    borderWidth: 1,
                  }}
                >
                  <Text
                    className="text-xs font-semibold"
                    style={{ color: selectedDept === dept ? "white" : colors.foreground }}
                  >
                    {dept}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Shelf Tips */}
          <View 
            className="rounded-2xl p-4 gap-2"
            style={{ backgroundColor: colors.success + "15" }}
          >
            <Text className="text-sm font-semibold text-foreground">💡 Wskazówki</Text>
            <Text className="text-xs text-foreground">
              • Grupuj produkty po typie{"\n"}
              • Umieść bestsellery na poziomie oczu{"\n"}
              • Nowe produkty na widocznym miejscu{"\n"}
              • Zmniejsz chaos wizualny{"\n"}
              • Używaj jasnych etykiet
            </Text>
          </View>

          {/* Problems List */}
          <View className="gap-2">
            <View className="flex-row items-center justify-between">
              <Text className="text-sm font-semibold text-foreground">
                Problemy ({deptProblems.length})
              </Text>
              <TouchableOpacity onPress={() => setShowAddProblem(!showAddProblem)}>
                <Text className="text-sm font-semibold text-primary">+ Dodaj</Text>
              </TouchableOpacity>
            </View>

            {showAddProblem && (
              <View 
                className="rounded-xl p-3 gap-2"
                style={{ backgroundColor: colors.surface, borderColor: colors.primary, borderWidth: 1 }}
              >
                <Text className="text-xs font-semibold text-foreground">Typ problemu:</Text>
                <View className="gap-2">
                  {PROBLEM_TYPES.map((type) => (
                    <TouchableOpacity
                      key={type.id}
                      onPress={() => setSelectedProblem(type.id)}
                      className="p-2 rounded-lg"
                      style={{
                        backgroundColor: selectedProblem === type.id ? colors.primary : colors.border,
                      }}
                    >
                      <Text
                        className="text-xs font-semibold"
                        style={{ color: selectedProblem === type.id ? "white" : colors.foreground }}
                      >
                        {type.emoji} {type.label}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>

                <TextInput
                  placeholder="Opis problemu"
                  placeholderTextColor={colors.muted}
                  value={newProblemTitle}
                  onChangeText={setNewProblemTitle}
                  className="p-2 rounded-lg border text-foreground"
                  style={{ borderColor: colors.border, color: colors.foreground }}
                  multiline
                />

                <View className="flex-row gap-2">
                  <TouchableOpacity
                    onPress={() => selectedProblem && addProblem(selectedProblem)}
                    disabled={!selectedProblem}
                    className="flex-1 rounded-lg p-2 items-center"
                    style={{
                      backgroundColor: selectedProblem ? colors.primary : colors.border,
                      opacity: selectedProblem ? 1 : 0.5,
                    }}
                  >
                    <Text className="text-xs font-semibold text-white">Dodaj</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      setShowAddProblem(false);
                      setSelectedProblem(null);
                      setNewProblemTitle("");
                    }}
                    className="flex-1 rounded-lg p-2 items-center"
                    style={{ backgroundColor: colors.border }}
                  >
                    <Text className="text-xs font-semibold text-foreground">Anuluj</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}

            {deptProblems.length === 0 ? (
              <View 
                className="rounded-xl p-4 items-center"
                style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
              >
                <Text className="text-sm text-muted">Brak problemów w tym dziale</Text>
              </View>
            ) : (
              deptProblems.map((problem) => (
                <View
                  key={problem.id}
                  className="p-3 rounded-lg gap-2"
                  style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
                >
                  <View className="flex-row items-start justify-between gap-2">
                    <View className="flex-1 gap-1">
                      <Text className="text-sm font-semibold text-foreground">{problem.title}</Text>
                      <Text className="text-xs text-muted">{problem.problem}</Text>
                    </View>
                    <TouchableOpacity onPress={() => deleteProblem(problem.id)}>
                      <Text className="text-lg text-error">✕</Text>
                    </TouchableOpacity>
                  </View>
                  <TouchableOpacity
                    onPress={() => resolveProblem(problem.id)}
                    className="rounded-lg p-2 items-center"
                    style={{ backgroundColor: colors.success }}
                  >
                    <Text className="text-xs font-semibold text-white">Rozwiązane</Text>
                  </TouchableOpacity>
                </View>
              ))
            )}
          </View>

          {/* Shelf Organization Guide */}
          <View 
            className="rounded-2xl p-4 gap-2"
            style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
          >
            <Text className="text-sm font-semibold text-foreground">📋 Przewodnik organizacji</Text>
            <Text className="text-xs text-muted">
              1. Zgrupuj produkty po typie{"\n"}
              2. Umieść bestsellery na poziomie oczu{"\n"}
              3. Nowe produkty na widocznym miejscu{"\n"}
              4. Usuń opakowania i etykiety{"\n"}
              5. Wyrównaj produkty na półce
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
