import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert } from "react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface Promotion {
  id: string;
  title: string;
  type: "clearance" | "bestseller" | "new" | "seasonal" | "action";
  products: string;
  location: string;
  startDate: string;
  endDate: string;
  notes: string;
}

const PROMOTION_TYPES = [
  { id: "clearance", label: "Wyprzedaż", emoji: "🏷️", color: "#E74C3C" },
  { id: "bestseller", label: "Bestseller", emoji: "⭐", color: "#F39C12" },
  { id: "new", label: "Nowość", emoji: "🆕", color: "#2ECC71" },
  { id: "seasonal", label: "Sezonowe", emoji: "🌸", color: "#00A8A8" },
  { id: "action", label: "Akcja", emoji: "🎯", color: "#FF6B35" },
];

export default function PromotionsScreen() {
  const colors = useColors();
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [showAddPromo, setShowAddPromo] = useState(false);
  const [newPromo, setNewPromo] = useState<Partial<Promotion>>({
    type: "clearance",
  });

  useEffect(() => {
    loadPromotions();
  }, []);

  const loadPromotions = async () => {
    try {
      const stored = await AsyncStorage.getItem("promotions");
      if (stored) {
        setPromotions(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading promotions:", error);
    }
  };

  const savePromotions = async (data: Promotion[]) => {
    try {
      await AsyncStorage.setItem("promotions", JSON.stringify(data));
      setPromotions(data);
    } catch (error) {
      console.error("Error saving promotions:", error);
    }
  };

  const addPromotion = () => {
    if (!newPromo.title?.trim() || !newPromo.products?.trim()) {
      Alert.alert("Błąd", "Wpisz tytuł i produkty");
      return;
    }

    const promotion: Promotion = {
      id: Date.now().toString(),
      title: newPromo.title,
      type: (newPromo.type as "clearance" | "bestseller" | "new" | "seasonal" | "action") || "clearance",
      products: newPromo.products,
      location: newPromo.location || "",
      startDate: newPromo.startDate || new Date().toISOString().split("T")[0],
      endDate: newPromo.endDate || "",
      notes: newPromo.notes || "",
    };

    savePromotions([...promotions, promotion]);
    setNewPromo({ type: "clearance" });
    setShowAddPromo(false);
  };

  const deletePromotion = (id: string) => {
    savePromotions(promotions.filter((p) => p.id !== id));
  };

  const getPromoTypeInfo = (type: string) => {
    return PROMOTION_TYPES.find((t) => t.id === type);
  };

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">Promocje i sprzedaż</Text>
            <Text className="text-sm text-muted">Zarządzanie promocjami i ekspozycjami</Text>
          </View>

          {/* Display Tips */}
          <View 
            className="rounded-2xl p-4 gap-2"
            style={{ backgroundColor: colors.warning + "15" }}
          >
            <Text className="text-sm font-semibold text-foreground">🎨 Wskazówki do ekspozycji</Text>
            <Text className="text-xs text-foreground">
              • Czysta, czytelna ekspozycja{"\n"}
              • Wyraźne ceny i rabaty{"\n"}
              • Logiczne rozmieszczenie{"\n"}
              • Atrakcyjne wizualnie{"\n"}
              • Łatwe do zrozumienia
            </Text>
          </View>

          {/* Add Promotion */}
          <View className="gap-2">
            <View className="flex-row items-center justify-between">
              <Text className="text-sm font-semibold text-foreground">Promocje ({promotions.length})</Text>
              <TouchableOpacity onPress={() => setShowAddPromo(!showAddPromo)}>
                <Text className="text-sm font-semibold text-primary">+ Dodaj</Text>
              </TouchableOpacity>
            </View>

            {showAddPromo && (
              <View 
                className="rounded-xl p-3 gap-3"
                style={{ backgroundColor: colors.surface, borderColor: colors.primary, borderWidth: 1 }}
              >
                <TextInput
                  placeholder="Tytuł promocji"
                  placeholderTextColor={colors.muted}
                  value={newPromo.title || ""}
                  onChangeText={(text) => setNewPromo({ ...newPromo, title: text })}
                  className="p-2 rounded-lg border text-foreground"
                  style={{ borderColor: colors.border, color: colors.foreground }}
                />

                <View className="gap-1">
                  <Text className="text-xs font-semibold text-foreground">Typ promocji:</Text>
                  <View className="flex-row flex-wrap gap-2">
                    {PROMOTION_TYPES.map((type) => (
                      <TouchableOpacity
                        key={type.id}
                        onPress={() => setNewPromo({ ...newPromo, type: type.id as any })}
                        className="px-3 py-1 rounded-full"
                        style={{
                          backgroundColor: newPromo.type === type.id ? type.color : colors.border,
                        }}
                      >
                        <Text
                          className="text-xs font-semibold"
                          style={{ color: newPromo.type === type.id ? "white" : colors.foreground }}
                        >
                          {type.emoji} {type.label}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <TextInput
                  placeholder="Produkty (np. kremy do twarzy, serum)"
                  placeholderTextColor={colors.muted}
                  value={newPromo.products || ""}
                  onChangeText={(text) => setNewPromo({ ...newPromo, products: text })}
                  className="p-2 rounded-lg border text-foreground"
                  style={{ borderColor: colors.border, color: colors.foreground }}
                  multiline
                />

                <TextInput
                  placeholder="Lokalizacja (np. Półka 3A, Kasa)"
                  placeholderTextColor={colors.muted}
                  value={newPromo.location || ""}
                  onChangeText={(text) => setNewPromo({ ...newPromo, location: text })}
                  className="p-2 rounded-lg border text-foreground"
                  style={{ borderColor: colors.border, color: colors.foreground }}
                />

                <TextInput
                  placeholder="Notatki (np. rabat 30%, do 15 kwietnia)"
                  placeholderTextColor={colors.muted}
                  value={newPromo.notes || ""}
                  onChangeText={(text) => setNewPromo({ ...newPromo, notes: text })}
                  className="p-2 rounded-lg border text-foreground"
                  style={{ borderColor: colors.border, color: colors.foreground }}
                  multiline
                />

                <View className="flex-row gap-2">
                  <TouchableOpacity
                    onPress={addPromotion}
                    className="flex-1 rounded-lg p-2 items-center"
                    style={{ backgroundColor: colors.primary }}
                  >
                    <Text className="text-xs font-semibold text-white">Dodaj</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      setShowAddPromo(false);
                      setNewPromo({ type: "clearance" });
                    }}
                    className="flex-1 rounded-lg p-2 items-center"
                    style={{ backgroundColor: colors.border }}
                  >
                    <Text className="text-xs font-semibold text-foreground">Anuluj</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}

            {promotions.length === 0 ? (
              <View 
                className="rounded-xl p-4 items-center"
                style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
              >
                <Text className="text-sm text-muted">Brak promocji. Dodaj pierwszą!</Text>
              </View>
            ) : (
              promotions.map((promo) => {
                const typeInfo = getPromoTypeInfo(promo.type);
                return (
                  <View
                    key={promo.id}
                    className="p-3 rounded-lg gap-2"
                    style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
                  >
                    <View className="flex-row items-start justify-between gap-2">
                      <View className="flex-1 gap-1">
                        <View className="flex-row items-center gap-2">
                          <Text className="text-lg">{typeInfo?.emoji}</Text>
                          <Text className="text-sm font-semibold text-foreground flex-1">
                            {promo.title}
                          </Text>
                        </View>
                        <Text className="text-xs text-muted">📦 {promo.products}</Text>
                        {promo.location && (
                          <Text className="text-xs text-muted">📍 {promo.location}</Text>
                        )}
                        {promo.notes && (
                          <Text className="text-xs text-muted">💬 {promo.notes}</Text>
                        )}
                      </View>
                      <TouchableOpacity onPress={() => deletePromotion(promo.id)}>
                        <Text className="text-lg text-error">✕</Text>
                      </TouchableOpacity>
                    </View>
                  </View>
                );
              })
            )}
          </View>

          {/* Signage Templates */}
          <View 
            className="rounded-2xl p-4 gap-2"
            style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
          >
            <Text className="text-sm font-semibold text-foreground">📝 Szablony etykiet</Text>
            <Text className="text-xs text-muted">
              Przykład etykiety:{"\n"}
              "PROMOCJA 30%{"\n"}
              Kremy do twarzy{"\n"}
              Do 15 kwietnia"
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
