import { ScrollView, Text, View, TouchableOpacity, Alert } from "react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface ShiftData {
  startTime: number | null;
  endTime: number | null;
  tasksCompleted: number;
  tasksTotal: number;
  risks: string[];
}

export default function HomeScreen() {
  const colors = useColors();
  const [shiftData, setShiftData] = useState<ShiftData>({
    startTime: null,
    endTime: null,
    tasksCompleted: 0,
    tasksTotal: 0,
    risks: [],
  });
  const [elapsedTime, setElapsedTime] = useState(0);
  const [isShiftActive, setIsShiftActive] = useState(false);

  // Load shift data on mount
  useEffect(() => {
    loadShiftData();
  }, []);

  // Timer effect
  useEffect(() => {
    if (!isShiftActive || shiftData.startTime === null) return;

    const interval = setInterval(() => {
      const now = Date.now();
      const elapsed = Math.floor((now - (shiftData.startTime ?? 0)) / 1000);
      setElapsedTime(elapsed);
    }, 1000);

    return () => clearInterval(interval);
  }, [isShiftActive, shiftData.startTime]);

  const loadShiftData = async () => {
    try {
      const stored = await AsyncStorage.getItem("shiftData");
      if (stored) {
        const data = JSON.parse(stored);
        setShiftData(data);
        setIsShiftActive(data.startTime !== null && data.endTime === null);
        if (data.startTime && data.endTime === null) {
          const elapsed = Math.floor((Date.now() - data.startTime) / 1000);
          setElapsedTime(elapsed);
        }
      }
    } catch (error) {
      console.error("Error loading shift data:", error);
    }
  };

  const saveShiftData = async (data: ShiftData) => {
    try {
      await AsyncStorage.setItem("shiftData", JSON.stringify(data));
    } catch (error) {
      console.error("Error saving shift data:", error);
    }
  };

  const startShift = () => {
    const now = Date.now();
    const newData: ShiftData = {
      startTime: now,
      endTime: null,
      tasksCompleted: 0,
      tasksTotal: 0,
      risks: [],
    };
    setShiftData(newData);
    setIsShiftActive(true);
    setElapsedTime(0);
    saveShiftData(newData);
    Alert.alert("Zmiana rozpoczęta", "Powodzenia w pracy!");
  };

  const endShift = () => {
    Alert.alert(
      "Zakończyć zmianę?",
      "Przejdziesz do podsumowania zmiany.",
      [
        { text: "Anuluj", onPress: () => {} },
        {
          text: "Zakończ",
          onPress: () => {
            const newData: ShiftData = {
              ...shiftData,
              endTime: Date.now(),
            };
            setShiftData(newData);
            setIsShiftActive(false);
            saveShiftData(newData);
            Alert.alert("Zmiana zakończona", "Dziękujemy za pracę!");
          },
        },
      ]
    );
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  };

  const progressPercent = shiftData.tasksTotal > 0 
    ? Math.round((shiftData.tasksCompleted / shiftData.tasksTotal) * 100)
    : 0;

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-6">
          {/* Header */}
          <View className="items-center gap-2">
            <Text className="text-3xl font-bold text-foreground">DM Assistant</Text>
            <Text className="text-sm text-muted">Asystent pracy w drogerii</Text>
          </View>

          {/* Shift Timer Card */}
          <View 
            className="rounded-2xl p-6 gap-4"
            style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
          >
            <Text className="text-sm font-semibold text-muted">CZAS PRACY</Text>
            <Text className="text-5xl font-bold text-primary text-center">
              {formatTime(elapsedTime)}
            </Text>
            <Text className="text-xs text-muted text-center">
              {isShiftActive ? "Zmiana w toku" : "Brak aktywnej zmiany"}
            </Text>
          </View>

          {/* Shift Status Card */}
          {isShiftActive && (
            <View 
              className="rounded-2xl p-4 gap-3"
              style={{ backgroundColor: colors.success + "15" }}
            >
              <View className="flex-row items-center justify-between">
                <Text className="text-sm font-semibold text-foreground">Postęp zadań</Text>
                <Text className="text-sm font-bold text-success">{progressPercent}%</Text>
              </View>
              <View 
                className="h-2 rounded-full overflow-hidden"
                style={{ backgroundColor: colors.border }}
              >
                <View 
                  className="h-full rounded-full"
                  style={{
                    backgroundColor: colors.success,
                    width: `${progressPercent}%`,
                  }}
                />
              </View>
              <Text className="text-xs text-muted">
                {shiftData.tasksCompleted} z {shiftData.tasksTotal} zadań
              </Text>
            </View>
          )}

          {/* Risks Section */}
          {shiftData.risks.length > 0 && (
            <View 
              className="rounded-2xl p-4 gap-2"
              style={{ backgroundColor: colors.warning + "15" }}
            >
              <Text className="text-sm font-semibold text-foreground">⚠️ Zagrożenia</Text>
              {shiftData.risks.map((risk, idx) => (
                <Text key={idx} className="text-xs text-foreground">
                  • {risk}
                </Text>
              ))}
            </View>
          )}

          {/* Quick Actions */}
          <View className="gap-3">
            {!isShiftActive ? (
              <TouchableOpacity
                onPress={startShift}
                className="rounded-xl p-4 items-center"
                style={{ backgroundColor: colors.primary }}
              >
                <Text className="text-base font-semibold text-white">Rozpocznij zmianę</Text>
              </TouchableOpacity>
            ) : (
              <TouchableOpacity
                onPress={endShift}
                className="rounded-xl p-4 items-center"
                style={{ backgroundColor: colors.error }}
              >
                <Text className="text-base font-semibold text-white">Zakończ zmianę</Text>
              </TouchableOpacity>
            )}
          </View>

          {/* Today's Focus */}
          <View 
            className="rounded-2xl p-4 gap-3"
            style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
          >
            <Text className="text-sm font-semibold text-foreground">Dzisiejsze priorytety</Text>
            <View className="gap-2">
              <Text className="text-xs text-muted">📋 Sprawdź plan zmiany w zakładce "Plan"</Text>
              <Text className="text-xs text-muted">👥 Przygotuj się do rozmów ze klientami</Text>
              <Text className="text-xs text-muted">🏷️ Sprawdź promocje i nowości</Text>
            </View>
          </View>

          {/* Info */}
          <View className="items-center">
            <Text className="text-xs text-muted text-center">
              Wszystkie dane są przechowywane lokalnie na Twoim urządzeniu
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
