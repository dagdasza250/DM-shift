import { ScrollView, Text, View, TouchableOpacity, TextInput, Alert } from "react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

interface KnowledgeItem {
  id: string;
  title: string;
  category: string;
  content: string;
  createdAt: string;
  archived: boolean;
}

const CATEGORIES = [
  { id: "checklist", label: "Checklista", emoji: "✓" },
  { id: "procedure", label: "Procedura", emoji: "📋" },
  { id: "product", label: "Produkt", emoji: "📦" },
  { id: "problem", label: "Problem & Rozwiązanie", emoji: "🔧" },
  { id: "observation", label: "Obserwacja", emoji: "👁️" },
  { id: "idea", label: "Pomysł", emoji: "💡" },
  { id: "shortage", label: "Brak towaru", emoji: "⚠️" },
];

export default function KnowledgeScreen() {
  const colors = useColors();
  const [items, setItems] = useState<KnowledgeItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState("checklist");
  const [showAddItem, setShowAddItem] = useState(false);
  const [newItem, setNewItem] = useState({ title: "", content: "" });
  const [expandedId, setExpandedId] = useState<string | null>(null);

  useEffect(() => {
    loadItems();
  }, []);

  const loadItems = async () => {
    try {
      const stored = await AsyncStorage.getItem("knowledgeBase");
      if (stored) {
        setItems(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Error loading knowledge base:", error);
    }
  };

  const saveItems = async (data: KnowledgeItem[]) => {
    try {
      await AsyncStorage.setItem("knowledgeBase", JSON.stringify(data));
      setItems(data);
    } catch (error) {
      console.error("Error saving knowledge base:", error);
    }
  };

  const addItem = () => {
    if (!newItem.title.trim() || !newItem.content.trim()) {
      Alert.alert("Błąd", "Wpisz tytuł i zawartość");
      return;
    }

    const item: KnowledgeItem = {
      id: Date.now().toString(),
      title: newItem.title,
      category: selectedCategory,
      content: newItem.content,
      createdAt: new Date().toISOString().split("T")[0],
      archived: false,
    };

    saveItems([...items, item]);
    setNewItem({ title: "", content: "" });
    setShowAddItem(false);
  };

  const deleteItem = (id: string) => {
    saveItems(items.filter((i) => i.id !== id));
  };

  const archiveItem = (id: string) => {
    saveItems(
      items.map((i) => (i.id === id ? { ...i, archived: !i.archived } : i))
    );
  };

  const categoryItems = items.filter(
    (i) => i.category === selectedCategory && !i.archived
  );
  const getCategoryInfo = (catId: string) =>
    CATEGORIES.find((c) => c.id === catId);

  return (
    <ScreenContainer className="p-4">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false}>
        <View className="flex-1 gap-4">
          {/* Header */}
          <View className="gap-2">
            <Text className="text-2xl font-bold text-foreground">Baza wiedzy</Text>
            <Text className="text-sm text-muted">Notatki, procedury, obserwacje</Text>
          </View>

          {/* Category Selector */}
          <View className="gap-2">
            <Text className="text-sm font-semibold text-foreground">Kategoria</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} className="gap-2">
              {CATEGORIES.map((cat) => (
                <TouchableOpacity
                  key={cat.id}
                  onPress={() => setSelectedCategory(cat.id)}
                  className="px-3 py-2 rounded-full flex-row items-center gap-1"
                  style={{
                    backgroundColor: selectedCategory === cat.id ? colors.primary : colors.surface,
                    borderColor: colors.border,
                    borderWidth: 1,
                  }}
                >
                  <Text className="text-sm">{cat.emoji}</Text>
                  <Text
                    className="text-xs font-semibold"
                    style={{ color: selectedCategory === cat.id ? "white" : colors.foreground }}
                  >
                    {cat.label}
                  </Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>

          {/* Add Item */}
          <View className="gap-2">
            <View className="flex-row items-center justify-between">
              <Text className="text-sm font-semibold text-foreground">
                {getCategoryInfo(selectedCategory)?.label} ({categoryItems.length})
              </Text>
              <TouchableOpacity onPress={() => setShowAddItem(!showAddItem)}>
                <Text className="text-sm font-semibold text-primary">+ Dodaj</Text>
              </TouchableOpacity>
            </View>

            {showAddItem && (
              <View 
                className="rounded-xl p-3 gap-2"
                style={{ backgroundColor: colors.surface, borderColor: colors.primary, borderWidth: 1 }}
              >
                <TextInput
                  placeholder="Tytuł"
                  placeholderTextColor={colors.muted}
                  value={newItem.title}
                  onChangeText={(text) => setNewItem({ ...newItem, title: text })}
                  className="p-2 rounded-lg border text-foreground"
                  style={{ borderColor: colors.border, color: colors.foreground }}
                />

                <TextInput
                  placeholder="Zawartość"
                  placeholderTextColor={colors.muted}
                  value={newItem.content}
                  onChangeText={(text) => setNewItem({ ...newItem, content: text })}
                  className="p-2 rounded-lg border text-foreground"
                  style={{ borderColor: colors.border, color: colors.foreground, minHeight: 100 }}
                  multiline
                  textAlignVertical="top"
                />

                <View className="flex-row gap-2">
                  <TouchableOpacity
                    onPress={addItem}
                    className="flex-1 rounded-lg p-2 items-center"
                    style={{ backgroundColor: colors.primary }}
                  >
                    <Text className="text-xs font-semibold text-white">Dodaj</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      setShowAddItem(false);
                      setNewItem({ title: "", content: "" });
                    }}
                    className="flex-1 rounded-lg p-2 items-center"
                    style={{ backgroundColor: colors.border }}
                  >
                    <Text className="text-xs font-semibold text-foreground">Anuluj</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}

            {categoryItems.length === 0 ? (
              <View 
                className="rounded-xl p-4 items-center"
                style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
              >
                <Text className="text-sm text-muted">Brak notatek w tej kategorii</Text>
              </View>
            ) : (
              categoryItems.map((item) => (
                <View
                  key={item.id}
                  className="rounded-lg overflow-hidden"
                  style={{ backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }}
                >
                  <TouchableOpacity
                    onPress={() =>
                      setExpandedId(expandedId === item.id ? null : item.id)
                    }
                    className="p-3 flex-row items-center justify-between"
                  >
                    <View className="flex-1">
                      <Text className="text-sm font-semibold text-foreground">
                        {item.title}
                      </Text>
                      <Text className="text-xs text-muted mt-1">{item.createdAt}</Text>
                    </View>
                    <Text className="text-lg text-primary">
                      {expandedId === item.id ? "▼" : "▶"}
                    </Text>
                  </TouchableOpacity>

                  {expandedId === item.id && (
                    <View 
                      className="p-3 gap-2"
                      style={{ backgroundColor: colors.background, borderTopColor: colors.border, borderTopWidth: 1 }}
                    >
                      <Text className="text-sm text-foreground leading-relaxed">
                        {item.content}
                      </Text>
                      <View className="flex-row gap-2 pt-2">
                        <TouchableOpacity
                          onPress={() => archiveItem(item.id)}
                          className="flex-1 rounded-lg p-2 items-center"
                          style={{ backgroundColor: colors.muted }}
                        >
                          <Text className="text-xs font-semibold text-white">
                            Archiwum
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                          onPress={() => deleteItem(item.id)}
                          className="flex-1 rounded-lg p-2 items-center"
                          style={{ backgroundColor: colors.error }}
                        >
                          <Text className="text-xs font-semibold text-white">
                            Usuń
                          </Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  )}
                </View>
              ))
            )}
          </View>

          {/* Templates Section */}
          <View 
            className="rounded-2xl p-4 gap-2"
            style={{ backgroundColor: colors.success + "15" }}
          >
            <Text className="text-sm font-semibold text-foreground">📝 Szablony</Text>
            <Text className="text-xs text-foreground">
              <Text className="font-semibold">Checklista poranna:</Text>{"\n"}
              ☐ Sprawdzić zapasy{"\n"}
              ☐ Sprawdzić promocje{"\n"}
              ☐ Sprawdzić daty{"\n"}
              {"\n"}
              <Text className="font-semibold">Problem & Rozwiązanie:</Text>{"\n"}
              Problem: ...{"\n"}
              Przyczyna: ...{"\n"}
              Rozwiązanie: ...
            </Text>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
