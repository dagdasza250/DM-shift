# DM Assistant - Design Document

## Overview

**DM Assistant** is a mobile work companion for DM drugstore employees. It transforms daily shift work into an organized, efficient, and less chaotic experience by providing practical guidance for customer service, product management, shelf organization, and shift planning.

---

## Screen List

### Core Navigation (Tab Bar)

1. **Home / Dashboard** — Start of shift, quick overview, shift status
2. **Shift Planner** — Organize tasks, priorities, risks, action plans
3. **Customer Advisory** — Structured sales conversations, product recommendations
4. **Shelf & Products** — Shelf layout, product placement, organization ideas
5. **Promotions & Sales** — Clearance management, displays, signage
6. **Knowledge Base** — Notes, checklists, procedures, observations

### Modal/Detail Screens

- **Shift Start Checklist** — Morning scan of tasks and risks
- **Shift End Summary** — Close shift, document observations
- **Product Detail** — Product info, placement suggestions, stock status
- **Customer Conversation Guide** — Step-by-step sales structure
- **Shelf Problem Solver** — Solutions for space issues, chaos reduction
- **Promotion Setup** — Create and manage promotional displays
- **Notion/OneNote Sync** — Connect and manage knowledge base

---

## Primary Content and Functionality

### 1. Home / Dashboard

**Content:**
- Current shift status (start time, elapsed time, remaining time)
- Quick summary: tasks completed, tasks pending, risks flagged
- Today's key focus areas (promotions, new products, inventory)
- Quick action buttons (start shift, end shift, add note)

**Functionality:**
- Display shift timer
- Show task progress bar
- One-tap access to most-used features
- Notification of urgent items (low stock, new arrivals)

### 2. Shift Planner

**Content:**
- Morning scan checklist (areas to check, risks to assess)
- Priority list (what to do first, second, third)
- Risk indicators (low stock, display issues, new products without placement)
- Action plan for the shift (structured tasks)
- End-of-shift summary template

**Functionality:**
- Create and edit daily task list
- Mark tasks as complete
- Reorder priorities
- Set risk flags
- Generate end-of-shift report

### 3. Customer Advisory

**Content:**
- Guided conversation structure (questions to ask, listening points)
- Product type selector (skincare, makeup, hair, hygiene, etc.)
- Recommendation framework (match customer needs to products)
- Safe, simple explanations for product benefits
- Alternative product suggestions
- Missing information checklist (before recommending)

**Functionality:**
- Step-by-step conversation guide
- Product search and filtering
- Save customer profiles/notes
- Quick reference cards for product categories
- Suggest alternatives based on customer needs

### 4. Shelf & Products

**Content:**
- Shelf layout visualizer (by department)
- Product placement suggestions for new items
- Solutions for "no space" problems
- Shelf readability checklist
- Visual chaos reduction tips
- Aesthetic display guidelines

**Functionality:**
- Browse by department (skincare, makeup, hair, hygiene, health, home, children)
- Add new product placement ideas
- Flag shelf problems
- Create display sketches or notes
- Suggest reorganization patterns

### 5. Promotions & Sales

**Content:**
- Clearance organization templates (especially cosmetics)
- Display setup guides (clean, readable, sales-focused)
- Product labeling templates
- Promotional messaging examples
- Bestseller, new product, seasonal, and action-focused tags
- Display photography/sketches

**Functionality:**
- Create promotion plan
- Generate signage templates
- Track clearance items
- Document display setup
- Share display ideas with team

### 6. Knowledge Base

**Content:**
- Shift checklists (daily, weekly, departmental)
- Product catalog and notes
- Problem-solution database (common shelf/sales issues)
- Shelf observations (what works, what doesn't)
- Stock shortage tracking
- Promotion notes and results
- Innovation ideas (low-cost, practical, brand-aligned)

**Functionality:**
- Create and edit notes
- Organize by category
- Search and filter
- Sync with Notion or OneNote (manual or API)
- Export checklists and templates
- Archive completed items

---

## Key User Flows

### Flow 1: Start of Shift
1. User opens app → Dashboard
2. Taps "Start Shift" → Timer begins
3. Navigates to Shift Planner
4. Reviews morning checklist
5. Identifies risks and priorities
6. Creates action plan for shift

### Flow 2: Customer Conversation
1. Customer approaches
2. User opens Customer Advisory
3. Selects product category (skincare, makeup, etc.)
4. Follows guided questions to understand needs
5. Gets product recommendations
6. Checks missing information before suggesting
7. Proposes alternatives if needed
8. Saves interaction notes (optional)

### Flow 3: Shelf Problem Solving
1. User encounters shelf space issue or new product
2. Opens Shelf & Products
3. Selects department and problem type
4. Gets suggestions for placement or reorganization
5. Documents solution with notes/sketch
6. Marks as resolved

### Flow 4: Promotion Setup
1. Manager announces clearance or promotion
2. User opens Promotions & Sales
3. Creates promotion plan (which products, where, how)
4. Generates signage templates
5. Documents display setup with photos/notes
6. Tracks promotion results

### Flow 5: End of Shift
1. User taps "End Shift" on Dashboard
2. Shift Planner shows summary
3. User documents observations (what worked, what didn't)
4. Marks completed tasks
5. Flags unfinished items for next shift
6. Syncs notes to knowledge base

---

## Color Choices

**Brand Colors (DM-inspired):**
- **Primary Teal**: `#00A8A8` — DM brand identity, trust, pharmacy
- **Accent Orange**: `#FF6B35` — Energy, promotions, calls-to-action
- **Success Green**: `#2ECC71` — Task completion, stock availability
- **Warning Amber**: `#F39C12` — Risks, low stock, attention needed
- **Error Red**: `#E74C3C` — Critical issues, out of stock

**Neutral Palette:**
- **Background**: `#F8F9FA` (light) / `#1A1A1A` (dark)
- **Surface**: `#FFFFFF` (light) / `#2D2D2D` (dark)
- **Text**: `#2C3E50` (light) / `#ECF0F1` (dark)
- **Muted**: `#7F8C8D` (secondary text)
- **Border**: `#BDC3C7` (light) / `#404040` (dark)

---

## Design Principles

1. **One-handed usage** — All controls within thumb reach on 6-inch screens
2. **Scannable layout** — Information hierarchy is clear and fast to read
3. **Practical, not pretty** — Function over decoration; every element serves a purpose
4. **Consistent with iOS** — Follows Apple Human Interface Guidelines
5. **Accessible** — Clear labels, sufficient contrast, readable fonts
6. **Offline-first** — Works without internet; syncs when available
7. **Quick actions** — Common tasks completed in 2-3 taps

---

## Implementation Notes

- All screens use `ScreenContainer` for proper SafeArea handling
- Tab bar navigation for main sections (Home, Planner, Advisory, Shelf, Promotions, Knowledge)
- Modal sheets for detailed editing and forms
- Local AsyncStorage for offline persistence
- Optional Notion/OneNote API integration (manual sync or webhooks)
- No authentication required (single-user, local app)
- No cloud sync by default (all data stays on device)
